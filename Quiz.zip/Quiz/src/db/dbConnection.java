/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.Connection;
/**
 *
 * @author kunal
 */
public class dbConnection {
    public Connection co;
    
    public dbConnection(){
      try{
          Class.forName("com.mysql.cj.jdbc.Driver");
          co=DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinequiz", "root", "");    
          System.out.println("Connection Successful");
      
      
      }catch( Exception e){
         System.out.println("Connection Failed");
         JOptionPane.showMessageDialog(null,e);
      }
    }

}
